import React from 'react';
import Navbar from '../component/Navbar';
import Accueil from '../component/Accueil';

function Division4() {
  return (
    <div>
      <Accueil />
      <Navbar></Navbar>
      <div></div>
    </div>
  );
}

export default Division4;